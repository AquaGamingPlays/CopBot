﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CopBotUI
{
    public partial class Form1 : Form
    {
        string size1;
        string size2;
        string size3;
        string size4;
        string size5;
        string size6;
        string size7;
        string size8;
        string size9;
        string size10;
        string size11;
        string size12;
        string size13;
        string size14;
        string size15;
        string size16;

        string ShopifyID1;
        string ShopifyID2;
        string ShopifyID3;
        string ShopifyID4;
        string ShopifyID5;
        string ShopifyID6;
        string ShopifyID7;
        string ShopifyID8;
        string ShopifyID9;
        string ShopifyID10;
        string ShopifyID11;
        string ShopifyID12;
        string ShopifyID13;
        string ShopifyID14;
        string ShopifyID15;
        string ShopifyID16;

        string[] ShopifyIDS = new string[16];

        string price;
        string title;

        string pictureUrl1;
        string pictureUrl2;
        string pictureUrl3;

        public Form1()
        {
            InitializeComponent();
            richTextBox1.Hide();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Remove(0);
            comboBox1.Items.Remove(1);
            comboBox1.Items.Remove(2);
            comboBox1.Items.Remove(3);
            comboBox1.Items.Remove(4);
            comboBox1.Items.Remove(5);
            comboBox1.Items.Remove(6);
            comboBox1.Items.Remove(7);
            comboBox1.Items.Remove(8);
            comboBox1.Items.Remove(9);
            comboBox1.Items.Remove(10);
            comboBox1.Items.Remove(11);
            comboBox1.Items.Remove(12);
            comboBox1.Items.Remove(13);
            comboBox1.Items.Remove(14);
            comboBox1.Items.Remove(15);

            pictureBox1.ImageLocation = null;
            pictureBox2.ImageLocation = null;
            pictureBox3.ImageLocation = null;

            size1 = null;
            size2 = null;
            size3 = null;
            size4 = null;
            size5 = null;
            size6 = null;
            size7 = null;
            size8 = null;
            size9 = null;
            size10 = null;
            size11= null;
            size12 = null;
            size13 = null;
            size14 = null;
            size15 = null;
            size16 = null;
            label1.Text = "Price: ";
            label2.Text = "Name: ";
            label3.Text = "Shopify Id: ";


            WebClient client = new WebClient();

            // Add a user agent header in case the 
            // requested URI contains a query.

            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");

            Stream data = client.OpenRead(textBox1.Text + ".xml");
            StreamReader reader = new StreamReader(data);
            string s = reader.ReadToEnd();
            richTextBox1.Text = s;
            data.Close();
            reader.Close();
            //String St = richTextBox1.Text;

            //int pFrom = St.IndexOf("<variant>") + "<variant>".Length;
            //int pTo = St.LastIndexOf("</variant>");
            string testforvariants = richTextBox1.Text;
            string[] name = richTextBox1.Text.Split(new[] { "<hash>", "<body-html>" }, StringSplitOptions.RemoveEmptyEntries);
            string[] images = richTextBox1.Text.Split(new[] { "<src>", "</src>" }, StringSplitOptions.RemoveEmptyEntries);
            string[] test = testforvariants.Split(new[] { "<variant>", "</variant>" }, StringSplitOptions.RemoveEmptyEntries);
            if (test.Length >= 0)
            {
                test[0] = "";
            }
            if (test.Length >= 2)
            {
                test[2] = "";
            }
            if (test.Length >= 4)
            {
                test[4] = "";
            }
            if (test.Length >= 6)
            {
                test[6] = "";
            }
            if (test.Length >= 8)
            {
                test[8] = "";
            }
            if (test.Length >= 10)
            {
                test[10] = "";
            }
            if (test.Length >= 12)
            {
                test[12] = "";
            }
            if (test.Length >= 14)
            {
                test[14] = "";
            }
            if (test.Length >= 16)
            {
                test[16] = "";
            }
            test = test.Where(x => !string.IsNullOrEmpty(x)).ToArray();
            //String result = St.Substring(pFrom, pTo - pFrom);


            if (images.Length >= 0)
            {
                images[0] = "";
            }
            if (images.Length >= 2)
            {
                images[2] = "";
            }
            if (images.Length >= 4)
            {
                images[4] = "";
            }
            if (images.Length >= 6)
            {
                images[6] = "";
            }
            if (images.Length >= 8)
            {
                images[8] = "";
            }
            images = images.Where(x => !string.IsNullOrEmpty(x)).ToArray();

            int i = test.Length - 1;
            var lol1 = "\n    ";
            foreach (string value in test)
            {

                if (test[i] == lol1)
                {
                    test[i] = "";
                }
                i = i - 1;
            }
            int length = test.Length;
            if (test[length - 1].Contains("</variants>"))
            {
                test[length - 1] = "";
            }
            test = test.Where(x => !string.IsNullOrEmpty(x)).ToArray();

            //var StartShopifyID = "<id type=\"integer\">";
            //var EndShopifyID = "</id>";

            if (test.Length - 1 >= 0)
            {
                title = Regex.Replace(name[1], "[\\s\\S]*<title>", "");//removes all leading data
                title = Regex.Replace(title, "</title>[\\s\\S]*", "");//removes all trailing data
                label2.Text = "Name: " + title;
                price = Regex.Replace(test[0], "[\\s\\S]*<price type=\"Money\">", "");
                price = Regex.Replace(price, "</price>[\\s\\S]*", "");//removes all trailing data
                label1.Text = "Price: $" + price;
                size1 = Regex.Replace(test[0], "[\\s\\S]*<title>", "");//removes all leading data
                size1 = Regex.Replace(size1, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID1 = Regex.Replace(test[0], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID1 = Regex.Replace(ShopifyID1, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[0] = ShopifyID1;
            }
            if (test.Length - 1 >= 1)
            {
                size2 = Regex.Replace(test[1], "[\\s\\S]*<title>", "");//removes all leading data
                size2 = Regex.Replace(size2, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID2 = Regex.Replace(test[1], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID2 = Regex.Replace(ShopifyID2, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[1] = ShopifyID2;
            }
            if (test.Length - 1 >= 2)
            {
                size3 = Regex.Replace(test[2], "[\\s\\S]*<title>", "");//removes all leading data
                size3 = Regex.Replace(size3, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID3 = Regex.Replace(test[2], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID3 = Regex.Replace(ShopifyID3, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[2] = ShopifyID3;
            }
            if (test.Length - 1 >= 3)
            {
                size4 = Regex.Replace(test[3], "[\\s\\S]*<title>", "");//removes all leading data
                size4 = Regex.Replace(size4, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID4 = Regex.Replace(test[3], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID4 = Regex.Replace(ShopifyID4, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[3] = ShopifyID4;
            }
            if (test.Length - 1 >= 4)
            {
                size5 = Regex.Replace(test[4], "[\\s\\S]*<title>", "");//removes all leading data
                size5 = Regex.Replace(size5, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID5 = Regex.Replace(test[4], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID5 = Regex.Replace(ShopifyID5, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[4] = ShopifyID5;
            }
            if (test.Length - 1 >= 5)
            {
                size6 = Regex.Replace(test[5], "[\\s\\S]*<title>", "");//removes all leading data
                size6 = Regex.Replace(size6, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID6 = Regex.Replace(test[5], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID6 = Regex.Replace(ShopifyID6, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[5] = ShopifyID6;
            }
            if (test.Length - 1 >= 6)
            {
                size7 = Regex.Replace(test[6], "[\\s\\S]*<title>", "");//removes all leading data
                size7 = Regex.Replace(size7, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID7 = Regex.Replace(test[6], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID7 = Regex.Replace(ShopifyID7, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[6] = ShopifyID7;
            }
            if (test.Length - 1 >= 7)
            {
                size8 = Regex.Replace(test[7], "[\\s\\S]*<title>", "");//removes all leading data
                size8 = Regex.Replace(size8, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID8 = Regex.Replace(test[7], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID8 = Regex.Replace(ShopifyID8, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[7] = ShopifyID8;
            }
            if (test.Length - 1 >= 8)
            {
                size9 = Regex.Replace(test[8], "[\\s\\S]*<title>", "");//removes all leading data
                size9 = Regex.Replace(size9, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID9 = Regex.Replace(test[8], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID9 = Regex.Replace(ShopifyID9, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[8] = ShopifyID9;
            }
            if (test.Length - 1 >= 9)
            {
                size10 = Regex.Replace(test[9], "[\\s\\S]*<title>", "");//removes all leading data
                size10 = Regex.Replace(size10, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID10 = Regex.Replace(test[9], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID10 = Regex.Replace(ShopifyID10, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[9] = ShopifyID10;
            }
            if (test.Length - 1 >= 10)
            {
                size11 = Regex.Replace(test[10], "[\\s\\S]*<title>", "");//removes all leading data
                size11 = Regex.Replace(size11, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID11 = Regex.Replace(test[10], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID11 = Regex.Replace(ShopifyID11, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[10] = ShopifyID11;
            }
            if (test.Length - 1 >= 11)
            {
                size12 = Regex.Replace(test[11], "[\\s\\S]*<title>", "");//removes all leading data
                size12 = Regex.Replace(size12, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID12 = Regex.Replace(test[11], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID12 = Regex.Replace(ShopifyID12, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[11] = ShopifyID12;
            }
            if (test.Length - 1 >= 12)
            {
                size13 = Regex.Replace(test[12], "[\\s\\S]*<title>", "");//removes all leading data
                size13 = Regex.Replace(size13, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID13 = Regex.Replace(test[12], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID13 = Regex.Replace(ShopifyID13, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[12] = ShopifyID13;
            }
            if (test.Length - 1 >= 13)
            {
                size14 = Regex.Replace(test[13], "[\\s\\S]*<title>", "");//removes all leading data
                size14 = Regex.Replace(size14, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID14 = Regex.Replace(test[13], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID14 = Regex.Replace(ShopifyID14, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[13] = ShopifyID14;
            }
            if (test.Length - 1 >= 14)
            {
                size15 = Regex.Replace(test[14], "[\\s\\S]*<title>", "");//removes all leading data
                size15 = Regex.Replace(size15, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID15 = Regex.Replace(test[14], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID15 = Regex.Replace(ShopifyID15, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[14] = ShopifyID15;
            }
            if (test.Length - 1 >= 15)
            {
                size16 = Regex.Replace(test[15], "[\\s\\S]*<title>", "");//removes all leading data
                size16 = Regex.Replace(size16, "</title>[\\s\\S]*", "");//removes all trailing data
                ShopifyID16 = Regex.Replace(test[15], "[\\s\\S]*<id type=\"integer\">", "");//removes all leading data
                ShopifyID16 = Regex.Replace(ShopifyID16, "</id>[\\s\\S]*", "");//removes all trailing data
                ShopifyIDS[15] = ShopifyID16;
            }

            //if(test[1] == lol1)
            //{
            //    test[1] = "";
            //}
            //if (test[2] == lol1)
            //{
            //    test[2] = "";
            //}
            //if (test[3] == lol1)
            //{
            //    test[3] = "";
            //}
            //if (test[4] == lol1)
            //{
            //    test[4] = "";
            //}
            //if (test[5] == lol1)
            //{
            //    test[5] = "";
            //}
            //if (test[6] == lol1)
            //{
            //    test[6] = "";
            //}
            //if (test[7] == lol1)
            //{
            //    test[7] = "";
            //}
            //if (test[8] == lol1)
            //{
            //    test[8] = "";
            //}
            //if (test[9] == lol1)
            //{
            //    test[9] = "";
            //}
            //if (test[10] == lol1)
            //{
            //    test[10] = "";
            //}
            //if (test[11] == lol1)
            //{
            //    test[11] = "";
            //}
            //if (test[12] == lol1)
            //{
            //    test[12] = "";
            //}
            pictureUrl1 = images[0];
            pictureUrl2 = images[1];
            pictureUrl3 = images[2];

            int index = pictureUrl1.IndexOf("?");
            if (index > 0)
                pictureUrl1 = pictureUrl1.Substring(0, index);

            int index2 = pictureUrl2.IndexOf("?");
            if (index2 > 0)
                pictureUrl2 = pictureUrl2.Substring(0, index2);

            int index3 = pictureUrl3.IndexOf("?");
            if (index3 > 0)
                pictureUrl3 = pictureUrl3.Substring(0, index3);

            if (size1 != null)
            {
                comboBox1.Items.Insert(0, size1);
            }
            if (size2 != null)
            {
                comboBox1.Items.Insert(1, size2);
            }
            if (size3 != null)
            {
                comboBox1.Items.Insert(2, size3);
            }
            if (size4 != null)
            {
                comboBox1.Items.Insert(3, size4);
            }
            if (size5 != null)
            {
                comboBox1.Items.Insert(4, size5);
            }
            if (size6 != null)
            {
                comboBox1.Items.Insert(5, size6);
            }
            if (size7 != null)
            {
                comboBox1.Items.Insert(6, size7);
            }
            if (size8 != null)
            {
                comboBox1.Items.Insert(7, size8);
            }
            if (size9 != null)
            {
                comboBox1.Items.Insert(8, size9);
            }
            if (size10 != null)
            {
                comboBox1.Items.Insert(9, size10);
            }
            if (size11 != null)
            {
                comboBox1.Items.Insert(10, size11);
            }
            if (size12 != null)
            {
                comboBox1.Items.Insert(11, size12);
            }
            if (size13 != null)
            {
                comboBox1.Items.Insert(12, size13);
            }
            if (size14 != null)
            {
                comboBox1.Items.Insert(13, size14);
            }
            if (size15 != null)
            {
                comboBox1.Items.Insert(14, size15);
            }
            if (size16 != null)
            {
                comboBox1.Items.Insert(15, size16);
            }


            pictureBox1.ImageLocation = pictureUrl1;
            pictureBox2.ImageLocation = pictureUrl2;
            pictureBox3.ImageLocation = pictureUrl3;
        }

        private void ComboChange(object sender, EventArgs e)
        {

            
            int selected = comboBox1.SelectedIndex;
            label3.Text = "Shopify Id: " + ShopifyIDS[selected];
        }
    }
}
 

